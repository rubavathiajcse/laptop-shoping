import { TestBed } from '@angular/core/testing';

import { LaptopstoreService } from './laptopstore.service';

describe('LaptopstoreService', () => {
  let service: LaptopstoreService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LaptopstoreService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
